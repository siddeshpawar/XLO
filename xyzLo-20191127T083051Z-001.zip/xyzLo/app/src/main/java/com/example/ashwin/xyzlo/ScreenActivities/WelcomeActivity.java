package com.example.ashwin.xyzlo.ScreenActivities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.ashwin.xyzlo.Fragments.WelcomeScreenFourFragment;
import com.example.ashwin.xyzlo.Fragments.WelcomeScreenOneFragment;
import com.example.ashwin.xyzlo.Fragments.WelcomeScreenThreeFragment;
import com.example.ashwin.xyzlo.Fragments.WelcomeScreenTwoFragment;
import com.example.ashwin.xyzlo.R;
import com.example.ashwin.xyzlo.Adapters.ViewPagerAdapter;

public class WelcomeActivity extends AppCompatActivity
{
    ViewPagerAdapter viewPagerAdapter;
    LinearLayout dotsLayout;
    ImageView[] dotsView;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = PreferenceManager
                .getDefaultSharedPreferences(this);
        if (!prefs.getBoolean("Time", false)) {

            // run your one time code
            setContentView(R.layout.activity_welcome);
            final ViewPager viewPager = findViewById(R.id.viewpager_welcome_id);
            viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
            viewPagerAdapter.addFragment(new WelcomeScreenOneFragment(),"One");
            viewPagerAdapter.addFragment(new WelcomeScreenTwoFragment(),"Two");
            viewPagerAdapter.addFragment(new WelcomeScreenThreeFragment(),"three");
            viewPagerAdapter.addFragment(new WelcomeScreenFourFragment(),"Four");
            viewPager.setAdapter(viewPagerAdapter);
            viewPager.setOffscreenPageLimit(1);
            dotsLayout = findViewById(R.id.dotsLayout);
            createDots(0);
            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener()
            {
                @Override
                public void onPageScrolled(int position,float positionOffset,int positionOffsetPixels)
                {
                }

                @Override
                public void onPageSelected(int position)
                {
                    createDots(position);
                }
                @Override
                public void onPageScrollStateChanged(int state)
                {
                }
            });
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("Time", true);
            editor.commit();
        }
        else
        {
            launchHomeScreen();
            finish();
        }
    }


    private void createDots(int currentPosition)
    {
        if(dotsLayout != null)
        {
            dotsLayout.removeAllViews();
        }
        dotsView = new ImageView[4];
        for(int i = 0;i < 4;i++)
        {
            dotsView[i] = new ImageView(this);
            if(i == currentPosition)
            {
                dotsView[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.active_dots));
            }else
            {
                dotsView[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.default_dot));
            }
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(8,0,8,0);
            dotsLayout.addView(dotsView[i],params);
        }
    }
    private void launchHomeScreen()
    {
        startActivity(new Intent(this,SignInActivity.class));
        finish();
    }
}