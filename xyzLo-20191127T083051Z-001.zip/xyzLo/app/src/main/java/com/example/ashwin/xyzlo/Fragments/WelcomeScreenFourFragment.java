package com.example.ashwin.xyzlo.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.ashwin.xyzlo.R;
import com.example.ashwin.xyzlo.ScreenActivities.SignInActivity;
import com.example.ashwin.xyzlo.ScreenActivities.SignUpActivity;

public class WelcomeScreenFourFragment extends android.support.v4.app.Fragment
{
    View rootView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState)
    {
        rootView = inflater.inflate(R.layout.welcome_screen4,container,false);
        final TextView threeLines = rootView.findViewById(R.id.money_id);
        threeLines.setVisibility(View.INVISIBLE);
        final ImageView imageView = rootView.findViewById(R.id.fourth_image);
        imageView.setVisibility(View.INVISIBLE);
        final TextView motto = rootView.findViewById(R.id.fourth_motto_id);
        motto.setVisibility(View.INVISIBLE);
        final ImageView first = rootView.findViewById(R.id.fourth_1);
        first.setVisibility(View.INVISIBLE);
        final ImageView second = rootView.findViewById(R.id.fourth_2);
        second.setVisibility(View.INVISIBLE);
        final ImageView third = rootView.findViewById(R.id.fourth_3);
        third.setVisibility(View.INVISIBLE);
        final ImageView fourth = rootView.findViewById(R.id.fourth_4);
        fourth.setVisibility(View.INVISIBLE);
        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                imageView.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                imageView.setVisibility(View.VISIBLE);
                threeLines.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                threeLines.setVisibility(View.VISIBLE);
                motto.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.blink_delay));
                motto.setVisibility(View.VISIBLE);
                first.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.rtl));
                first.setVisibility(View.VISIBLE);
                second.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.rtl));
                second.setVisibility(View.VISIBLE);
                third.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.rtl));
                third.setVisibility(View.VISIBLE);
                fourth.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.rtl));
                fourth.setVisibility(View.VISIBLE);
            }
        },1500);

        Button doneAcitivity = rootView.findViewById(R.id.done_activity_id);
        doneAcitivity.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(getContext(),SignInActivity.class));
                getActivity().finish();
            }
        });
        return rootView;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
    }
}


