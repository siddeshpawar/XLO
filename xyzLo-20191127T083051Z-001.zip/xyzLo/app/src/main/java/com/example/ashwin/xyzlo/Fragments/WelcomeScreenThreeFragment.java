package com.example.ashwin.xyzlo.Fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ashwin.xyzlo.R;

public class WelcomeScreenThreeFragment extends Fragment
{
    View rootView;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }


    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState)
    {
        rootView = inflater.inflate(R.layout.welcome_screen3,container,false);
        final TextView reason = rootView.findViewById(R.id.reason_id);
        final ImageView imageView = rootView.findViewById(R.id.third_image_id);
        final TextView motto = rootView.findViewById(R.id.third_motto_id);
        reason.setVisibility(View.INVISIBLE);
        imageView.setVisibility(View.INVISIBLE);
        motto.setVisibility(View.INVISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                imageView.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                imageView.setVisibility(View.VISIBLE);
                motto.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.blink));
                motto.setVisibility(View.VISIBLE);
                reason.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                reason.setVisibility(View.VISIBLE);

            }
        }, 1000);
        return rootView;
    }
}
