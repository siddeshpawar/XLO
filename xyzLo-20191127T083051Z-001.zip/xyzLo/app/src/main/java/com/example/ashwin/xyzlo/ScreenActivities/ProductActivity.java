package com.example.ashwin.xyzlo.ScreenActivities;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationProvider;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SearchView;
import android.widget.Toast;


import com.example.ashwin.xyzlo.ObjectItems.AdItem;
import com.example.ashwin.xyzlo.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.example.ashwin.xyzlo.ScreenActivities.SignUpActivity.REQUEST_TAKE_PHOTO;

public class ProductActivity extends AppCompatActivity
{

    EditText nodays, documents, deposit, description, perdaycost, onlinePay;
    Button photo, submitForm, locationButton;
    FirebaseAuth mAuth;
    FusedLocationProviderClient mFusedLocationProvider;
    String photoUploadPath;
    String path;
    DatabaseReference databaseReference;
    RadioGroup radioGroup;
    String availability,online_,documents_,description_;
    double lat, longitude;

    @Override
    protected void onCreate(final Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        mFusedLocationProvider = LocationServices.getFusedLocationProviderClient(ProductActivity.this);
        mAuth = FirebaseAuth.getInstance();
        Intent intent = getIntent();
        final String category = intent.getStringExtra("CategoryName");
        radioGroup = findViewById(R.id.r_group);
        nodays = findViewById(R.id.nodays);
        nodays.setTextColor(Color.BLACK);
        documents = findViewById(R.id.docs);
        deposit = findViewById(R.id.deposit);
        locationButton = findViewById(R.id.getLocation);
        onlinePay = findViewById(R.id.onlinepay);
        description = findViewById(R.id.description);
        perdaycost = findViewById(R.id.perdaycost);
        photo = findViewById(R.id.upload);
        photo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dispatchTakePictureIntent();
            }
        });
        submitForm = findViewById(R.id.submit_form);
        locationButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                ActivityCompat.requestPermissions(ProductActivity.this,new String[]
                        {Manifest.permission.ACCESS_FINE_LOCATION},1);
            }

        });
        databaseReference = FirebaseDatabase.getInstance().getReference();
        submitForm.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(radioGroup.getCheckedRadioButtonId() == R.id.yes)
                {
                    availability = "Yes";
                }else if(radioGroup.getCheckedRadioButtonId() == R.id.no)
                {
                    availability = "No";
                }
                if(!(radioGroup.getCheckedRadioButtonId() == R.id.yes && radioGroup.getCheckedRadioButtonId() == R.id.yes) || perdaycost.getText().toString().equals("") || nodays.getText().toString().equals(""))
                {
                    Toast.makeText(ProductActivity.this,"Enter the details marked *",Toast.LENGTH_SHORT).show();
                }
                online_ = onlinePay.getText().toString();
                if(online_ == "")
                {
                    online_ = "NA";
                }
                documents_ = documents.getText().toString();
                if(documents_ == "")
                {
                    documents_ = "NA";
                }
                description_ = description.getText().toString();
                if(description_ == "")
                {
                    description_ = "NA";
                }

                final StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(mAuth.getUid() + "/" + "productPhoto.jpeg");
                UploadTask uploadTask = storageReference.putFile(Uri.fromFile(new File(photoUploadPath)));
                Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot,Task<Uri>>()
                {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception
                    {
                        if(!task.isSuccessful())
                        {
                            throw task.getException();
                        }
                        return storageReference.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>()
                {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task)
                    {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(ProductActivity.this,"Uploaded",Toast.LENGTH_SHORT).show();
                            Uri downloadUri = task.getResult();
                            path = downloadUri.toString();
                            AdItem adItem = new AdItem(availability,Integer.parseInt(nodays.getText().toString()),Double.parseDouble(perdaycost.getText().toString()),
                                    Double.parseDouble(deposit.getText().toString()),path,
                                    description_,documents_,online_,lat,longitude);
                            databaseReference.child("users").child(category).child(mAuth.getUid()).push().setValue(adItem);
                            databaseReference.child("ads").child(category).push().setValue(adItem);
                            Toast.makeText(ProductActivity.this,"Ad registered,Thank you!",Toast.LENGTH_SHORT).show();
                        }
                    }
                });




            }
        });


    }

    private void dispatchTakePictureIntent()
    {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if(takePictureIntent.resolveActivity(getPackageManager()) != null)
        {
            // Create the File where the photo should go
            File photoFile = null;
            try
            {
                photoFile = createImageFile();
            }catch(IOException ex)
            {
                // Error occurred while creating the File
                ex.printStackTrace();
            }
            // Continue only if the File was successfully created
            if(photoFile != null)
            {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.ashwin.xyzlo.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,photoURI);
                startActivityForResult(takePictureIntent,REQUEST_TAKE_PHOTO);
            }
        }
    }

    private File createImageFile() throws IOException
    {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        photoUploadPath = image.getAbsolutePath();
        return image;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults)
    {
        switch(requestCode)
        {
            case 1:
            {
                // If request is cancelled, the result arrays are empty.
                if(grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                   try
                   {
                       mFusedLocationProvider.getLastLocation()
                               .addOnSuccessListener(this,new OnSuccessListener<Location>()
                               {
                                   @Override
                                   public void onSuccess(Location location)
                                   {
                                       // Got last known location. In some rare situations this can be null.
                                       if(location != null)
                                       {
                                           // Logic to handle location object
                                           lat = location.getLatitude();
                                           longitude = location.getLongitude();
                                           Toast.makeText(ProductActivity.this,"Location stored",Toast.LENGTH_SHORT).show();
                                       }
                                   }
                               });
                   }catch(SecurityException e)
                   {
                       e.printStackTrace();
                   }
                }
            }
        }
    }
}
