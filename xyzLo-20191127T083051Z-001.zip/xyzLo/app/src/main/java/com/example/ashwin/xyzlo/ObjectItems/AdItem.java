package com.example.ashwin.xyzlo.ObjectItems;

public class AdItem
{

    private String availability;
    private int noOfDays;
    private double perDayCost;
    private double deposit;
    private String requiredDocuments;
    private String photo;
    private String description;
    private String onlinePaymentOptions;
    private double latitude,longitude;

    public AdItem(String availability,int noOfDays,double perDayCost,double deposit,String photo,String description,String requiredDocuments,String onlinePaymentOptions,double latitude,double longitude)
    {
        this.availability = availability;
        this.noOfDays = noOfDays;
        this.perDayCost = perDayCost;
        this.deposit = deposit;
        this.photo = photo;
        this.description = description;
        this.requiredDocuments = requiredDocuments;
        this.onlinePaymentOptions = onlinePaymentOptions;
        this.latitude = latitude;
        this.longitude = longitude;

    }

    public double getPerDayCost()
    {
        return perDayCost;
    }

    public int getNoOfDays()
    {
        return noOfDays;
    }

    public String getAvailability()
    {
        return availability;
    }

    public String getDescription()
    {
        return description;
    }

    public String getPhoto()
    {
        return photo;
    }

    public String getOnlinePaymentOptions()
    {
        return onlinePaymentOptions;
    }

    public String getRequiredDocuments()
    {
        return requiredDocuments;
    }

    public double getDeposit()
    {
        return deposit;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }
}
