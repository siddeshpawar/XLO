package com.example.ashwin.xyzlo.Fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ashwin.xyzlo.R;

public class WelcomeScreenOneFragment extends Fragment
{

    View rootView;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState)
    {
        rootView = inflater.inflate(R.layout.welcome_screen1,container,false);
        TextView welcome = rootView.findViewById(R.id.first_text_1);
        TextView motto = rootView.findViewById(R.id.first_motto_1);
        TextView rental = rootView.findViewById(R.id.first_rental_1);
        ImageView imageView = rootView.findViewById(R.id.first_image_1);
        Animation animation = AnimationUtils.loadAnimation(getActivity().getApplicationContext(),R.anim.fade_in);
        welcome.startAnimation(animation);
        imageView.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.rotate));
        motto.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
        rental.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
        return rootView;
    }

    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
    }
}
