package com.example.ashwin.xyzlo.ScreenActivities;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.ashwin.xyzlo.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;

public class MainActivity extends AppCompatActivity
{

    FirebaseAuth mAuth;
    Button rentButton,shopButton;
    String userId;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        Toolbar toolbar = findViewById(R.id.main_toolbar_id);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();
        final String photoUrl = intent.getStringExtra("string");
        rentButton = findViewById(R.id.rent_button_id);
        shopButton = findViewById(R.id.shop_button_id);
        rentButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                startActivity(new Intent(MainActivity.this,CategoryActivity.class));
            }
        });
        shopButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(MainActivity.this,BuySearchActivity.class));
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.signout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.sign_out_id: FirebaseAuth.getInstance().signOut();
                                    startActivity(new Intent(MainActivity.this,SignInActivity.class));
                                    finish();
                                    return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
