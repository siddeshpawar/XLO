package com.example.ashwin.xyzlo.ScreenActivities;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ashwin.xyzlo.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class SignUpActivity extends AppCompatActivity
{
    TextView t_name,t_address,t_date,t_mobile,t_otp,t_email,t_aadhar,t_password,t_re_password,t_thanks,t_username;
    EditText name, address, date, mobile, otp, email, password, re_password;
    Button scanAadhar,signIn;
    FirebaseAuth mAuth;
    PhoneAuthProvider.ForceResendingToken mForceResendingToken;
    String mVerificationId;
    String code;
    String userId;
    String entered_email,entered_password;
    Calendar myCalender;
    String mCurrentPhotoPath ="";
    AuthCredential authCredential;
    static final int REQUEST_TAKE_PHOTO = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        myCalender = Calendar.getInstance();
        mAuth = FirebaseAuth.getInstance();
        t_name = findViewById(R.id.full_name_id);
        name = findViewById(R.id.enter_name_id);
        name.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                if(actionId == EditorInfo.IME_ACTION_NEXT)
                {
                    t_name.setVisibility(View.INVISIBLE);
                    name.setVisibility(View.INVISIBLE);
                    InputMethodManager imm = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(
                            name.getWindowToken(), 0);
                    t_address.setVisibility(View.VISIBLE);
                    address.setVisibility(View.VISIBLE);
                    return true;
                }
                return false;
            }
        });
        t_address = findViewById(R.id.address_id);
        address = findViewById(R.id.enter_address_id);
        address.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                t_address.setVisibility(View.INVISIBLE);
                address.setVisibility(View.INVISIBLE);
                InputMethodManager imm = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(
                        address.getWindowToken(), 0);
                t_date.setVisibility(View.VISIBLE);
                date.setVisibility(View.VISIBLE);
                return true;
            }
        });
        t_date = findViewById(R.id.date_id);
        date = findViewById(R.id.enter_date_id);
        final DatePickerDialog.OnDateSetListener set_date = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view,int year,int month,int dayOfMonth)
            {
                myCalender.set(Calendar.YEAR,year);
                myCalender.set(Calendar.MONTH,month);
                myCalender.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                updateLabel();
                new Handler().postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        t_date.setVisibility(View.INVISIBLE);
                        date.setVisibility(View.INVISIBLE);

                        t_mobile.setVisibility(View.VISIBLE);
                        mobile.setVisibility(View.VISIBLE);
                    }
                },1000);
            }
        };
        date.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                new DatePickerDialog(SignUpActivity.this,set_date,myCalender.get(Calendar.YEAR),
                        myCalender.get(Calendar.MONTH),myCalender.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        t_mobile = findViewById(R.id.mobile_id);
        mobile = findViewById(R.id.enter_mobile_id);
        mobile.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                getOtp("+91"+mobile.getText().toString());
                t_mobile.setVisibility(View.INVISIBLE);
                mobile.setVisibility(View.INVISIBLE);
                InputMethodManager imm = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(
                        mobile.getWindowToken(), 0);
                t_otp.setVisibility(View.VISIBLE);
                otp.setVisibility(View.VISIBLE);
                return true;
            }
        });
        t_otp = findViewById(R.id.otp_id);
        otp = findViewById(R.id.enter_otp_id);
        otp.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                verifyPhoneWithCode(mVerificationId,otp.getText().toString());
                code = otp.getText().toString();
                return true;
            }
        });
        t_email = findViewById(R.id.email_id);
        email = findViewById(R.id.enter_email_id);
        entered_email = email.getText().toString();
        email.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                t_email.setVisibility(View.INVISIBLE);
                email.setVisibility(View.INVISIBLE);
                InputMethodManager imm = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(
                        email.getWindowToken(), 0);
                t_aadhar.setVisibility(View.VISIBLE);
                scanAadhar.setVisibility(View.VISIBLE);
                return true;
            }
        });
        t_aadhar = findViewById(R.id.aadhar_id);
        scanAadhar = findViewById(R.id.submit_aadhar);
        scanAadhar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                dispatchTakePictureIntent();
                t_aadhar.setVisibility(View.INVISIBLE);
                scanAadhar.setVisibility(View.INVISIBLE);
                new Handler().postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        t_password.setVisibility(View.VISIBLE);
                        password.setVisibility(View.VISIBLE);
                        t_re_password.setVisibility(View.VISIBLE);
                        re_password.setVisibility(View.VISIBLE);
                        if(!(password.getText().toString().equals(re_password.getText().toString())))
                        {
                            Toast.makeText(getApplicationContext(),"Passwords do not match",Toast.LENGTH_SHORT).show();
                        }
                    }
                },1000);
            }
        });
        t_password = findViewById(R.id.password_id);
        password = findViewById(R.id.enter_password_id);
        t_re_password = findViewById(R.id.reenter_id);
        re_password = findViewById(R.id.enter_reenter_id);
        re_password.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                t_password.setVisibility(View.INVISIBLE);
                password.setVisibility(View.INVISIBLE);
                t_re_password.setVisibility(View.INVISIBLE);
                re_password.setVisibility(View.INVISIBLE);
                if(!(password.getText().toString().equals(re_password.getText().toString())))
                {
                    Toast.makeText(getApplicationContext(),"Passwords do not match",Toast.LENGTH_SHORT).show();
                    t_password.setVisibility(View.VISIBLE);
                    password.setVisibility(View.VISIBLE);
                    t_re_password.setVisibility(View.VISIBLE);
                    re_password.setVisibility(View.VISIBLE);
                }
                else
                {
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(
                            re_password.getWindowToken(),0);
                    t_thanks.setVisibility(View.VISIBLE);
                    t_username.setVisibility(View.VISIBLE);
                    signIn.setVisibility(View.VISIBLE);
                }
                return true;
            }
        });

        t_thanks = findViewById(R.id.thanks_id);
        t_username = findViewById(R.id.username_id);
        signIn = findViewById(R.id.signin_button_id);
        signIn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                authCredential = EmailAuthProvider.getCredential(email.getText().toString(),re_password.getText().toString());
                mAuth.getCurrentUser().linkWithCredential(authCredential).addOnCompleteListener(new OnCompleteListener<AuthResult>()
                {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task)
                    {
                        if (task.isSuccessful()) {
                            Toast.makeText(SignUpActivity.this,"Link success",Toast.LENGTH_SHORT).show();
                            userId = mAuth.getCurrentUser().getUid();
                            //UploadTask uploadTask = FirebaseStorage.getInstance().getReference().child("images"+userId).putFile(Uri.fromFile(new File(mCurrentPhotoPath)));
                            StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(userId+"/"+"aadhar.jpeg");
                            storageReference.putFile(Uri.fromFile(new File(mCurrentPhotoPath))).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>()
                            {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                                {
                                    Toast.makeText(SignUpActivity.this,"Done",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                });
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(SignUpActivity.this,SignInActivity.class));
                finish();
            }
        });

    }
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.printStackTrace();
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.example.ashwin.xyzlo.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
            }
        }
    }

    private void updateLabel() {
        String myFormat = "dd/MM/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.ENGLISH);
        date.setText(sdf.format(myCalender.getTime()));
    }
    private File createImageFile() throws IOException
    {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }



    private void getOtp(String phoneNumber)
    {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,
                60,
                TimeUnit.SECONDS,
                this,
                mCallbacks
        );
    }
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks()
    {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential)
        {
            signInWithPhoneAuthCredential(phoneAuthCredential);
        }

        @Override
        public void onVerificationFailed(FirebaseException e)
        {
            Toast.makeText(SignUpActivity.this,"Failed phone",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCodeSent(String s,PhoneAuthProvider.ForceResendingToken forceResendingToken)
        {
            mVerificationId = s;
            mForceResendingToken = forceResendingToken;
        }
    };

    private void verifyPhoneWithCode(String verificationId,String code)
    {
        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(verificationId,code);
        signInWithPhoneAuthCredential(phoneAuthCredential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential phoneAuthCredential)
    {
        mAuth.signInWithCredential(phoneAuthCredential).addOnCompleteListener(this,new OnCompleteListener<AuthResult>()
        {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {
                if(task.isSuccessful())
                {
                    Toast.makeText(SignUpActivity.this,"Success",Toast.LENGTH_SHORT).show();
                    t_otp.setVisibility(View.INVISIBLE);
                    otp.setVisibility(View.INVISIBLE);
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(
                            otp.getWindowToken(), 0);
                    t_email.setVisibility(View.VISIBLE);
                    email.setVisibility(View.VISIBLE);
                }
                else
                {
                    Toast.makeText(SignUpActivity.this,"Failure",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
