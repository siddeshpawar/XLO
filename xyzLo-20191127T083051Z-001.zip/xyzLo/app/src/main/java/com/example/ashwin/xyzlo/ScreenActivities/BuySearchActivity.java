package com.example.ashwin.xyzlo.ScreenActivities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.example.ashwin.xyzlo.R;
import com.google.android.gms.maps.MapView;

public class BuySearchActivity extends AppCompatActivity
{
    EditText searchBar;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_search);
        searchBar = findViewById(R.id.search_product);
        searchBar.setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v,int actionId,KeyEvent event)
            {
                if(actionId == EditorInfo.IME_ACTION_SEARCH)
                {
                    String searchQuery = searchBar.getText().toString();
                    Intent intent = new Intent(BuySearchActivity.this,SearchResultsActivity.class);
                    intent.putExtra("searchQuery",searchQuery);
                    startActivity(intent);
                    return true;
                }
                return false;
            }
        });
    }
}
