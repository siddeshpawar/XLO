package com.example.ashwin.xyzlo.Fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ashwin.xyzlo.R;

public class WelcomeScreenTwoFragment extends Fragment
{
    View rootView;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }


    @Override
    public void onDestroyView()
    {
        super.onDestroyView();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState)
    {
        rootView = inflater.inflate(R.layout.welcome_screen2,container,false);
        final TextView firstText = rootView.findViewById(R.id.second_welcome_2);
        final TextView secondText = rootView.findViewById(R.id.second_name_2_text);
        final ImageView imageView = rootView.findViewById(R.id.second_iamge_2);
        final TextView thirdText = rootView.findViewById(R.id.second_welcome_2_motto);
        firstText.setVisibility(View.INVISIBLE);
        secondText.setVisibility(View.INVISIBLE);
        imageView.setVisibility(View.INVISIBLE);
        thirdText.setVisibility(View.INVISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                firstText.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                firstText.setVisibility(View.VISIBLE);
                secondText.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                secondText.setVisibility(View.VISIBLE);
                imageView.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                imageView.setVisibility(View.VISIBLE);
                thirdText.startAnimation(AnimationUtils.loadAnimation(getContext(),R.anim.fade_in));
                thirdText.setVisibility(View.VISIBLE);
            }
        }, 1500);
        return rootView;
    }
}
